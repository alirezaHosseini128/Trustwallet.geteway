export default function Home() {
  const handlePay = () => {
    const to = "0x1111111111111111111111111111111111111111"; // آدرس کیف‌پول مقصد
    const amount = "0.01"; // مقدار BNB
    const deeplink = `https://link.trustwallet.com/send?address=${to}&asset=c56&amount=${amount}`;
    window.location.href = deeplink;
  };

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', flexDirection: 'column' }}>
      <h1>Trust Wallet Payment</h1>
      <button onClick={handlePay} style={{ padding: '12px 24px', fontSize: '18px', borderRadius: '8px', cursor: 'pointer', backgroundColor: '#2e7d32', color: '#fff' }}>
        پرداخت با Trust Wallet
      </button>
    </div>
  );
}